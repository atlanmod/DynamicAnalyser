package com.tblf.SimpleProject;
public class App implements IApp
{
	public void method() {
		System.out.println("The method");
		System.out.println("is being called");
	}
}
