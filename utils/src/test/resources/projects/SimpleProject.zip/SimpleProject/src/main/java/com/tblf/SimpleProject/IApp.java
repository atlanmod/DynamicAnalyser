package com.tblf.SimpleProject;

public interface IApp {

	public void method();

}
