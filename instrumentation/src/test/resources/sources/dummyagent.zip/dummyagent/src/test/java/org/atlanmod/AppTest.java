package org.atlanmod;

import org.junit.Test;

public class AppTest {

    @Test
    public void test() {
        App.main(new String[]{});
    }
}
