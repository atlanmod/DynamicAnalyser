package org.atlanmod;

import java.lang.instrument.Instrumentation;

/**
 * Hello world!
 *
 */
public class App 
{
    private static Instrumentation instrumentation;

    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Object o = new Object();
        System.out.println(sizeof(o));
    }

    public static void premain(String args, Instrumentation inst) {
        instrumentation = inst;
    }

    public static long sizeof(Object o) {
        return instrumentation.getObjectSize(o);
    }
}
