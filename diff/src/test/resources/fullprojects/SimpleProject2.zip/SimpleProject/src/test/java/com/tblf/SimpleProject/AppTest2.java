package com.tblf.SimpleProject;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest2 {
    
	@Test
	public void testApp() {
        System.out.println("New class!");
		new App().method();
	}

}
