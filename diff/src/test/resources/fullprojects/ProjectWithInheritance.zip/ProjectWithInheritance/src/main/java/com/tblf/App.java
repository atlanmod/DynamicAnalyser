package com.tblf;

/**
 * Hello world!
 *
 */
public class App extends SuperApp
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public void method (String value) {
        System.out.println(value+" hi!");
    }

    @Override
    public void superMethod(String param1, String param2) {
        System.out.println(param1+" ---> "+param2);
    }
}
