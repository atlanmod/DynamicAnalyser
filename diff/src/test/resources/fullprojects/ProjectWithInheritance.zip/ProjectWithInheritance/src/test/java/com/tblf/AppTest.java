package com.tblf;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    @Test
    public void test() {
        new App().superMethod("param1", "param2");
    }

    @Test
    public void test2() {
        new App().method("param1");
    }
}
