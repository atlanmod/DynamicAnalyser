package com.tblf;

public class SuperApp {

    public void superMethod(String param1, String param2) {
        System.out.println(param1+" - "+param2);
    }
}
